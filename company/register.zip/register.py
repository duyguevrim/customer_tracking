from sehatek import db, bcrypt
from sehatek.models import User
from musteri.models import Odeme, Musteri, Tahsilat, Indirim
from guncel_modul.models import GuncelOdeme
from guncel_modul.models import Siparis, TemsilciOranlari
from openpyxl import Workbook, load_workbook
from sqlalchemy import func
from datetime import date, timedelta
from datetime import datetime
from sqlalchemy import extract,and_
from datetime import date
from sqlalchemy import text
from sehatek.models import *
from musteri.models import *
from sqlalchemy import desc,asc

#
# portal_rapor_excel = Workbook()
# portal_rapor_sheet = portal_rapor_excel.active
# siparisler = Siparis.query.filter(extract('month', Siparis.son_odeme_tarihi) == 11 ).order_by(asc(Siparis.user_id)).all()
# i=2
# for siparis in siparisler:
#     user = User.query.get(siparis.user_id)
#     print(user.name)
#     temp='Merve Keçili'
#     if temp==user.name:
#         user = User.query.get(siparis.user_id)
#         portal_rapor_sheet["A" + str(i)].value = user.name
#         portal_rapor_sheet["B" + str(i)].value = siparis.musteri_adi
#         portal_rapor_sheet["C" + str(i)].value = siparis.proje_no
#         portal_rapor_sheet["D" + str(i)].value = siparis.siparis_tutari
#         portal_rapor_sheet["E" + str(i)].value = siparis.tahsilat
#         portal_rapor_sheet["F" + str(i)].value = siparis.son_odeme_tarihi
#         i +=1
#     elif temp!=user.name:
#         temp=user.name
#         ws = portal_rapor_excel.create_sheet(user.name)
#         ws_new = ws[user.name]
#         ws_new["A" + str(i)].value = user.name
#         ws_new["B" + str(i)].value = siparis.musteri_adi
#         ws_new["C" + str(i)].value = siparis.proje_no
#         ws_new["D" + str(i)].value = siparis.siparis_tutari
#         ws_new["E" + str(i)].value = siparis.tahsilat
#         ws_new["F" + str(i)].value = siparis.son_odeme_tarihi
#
#



# from musteri.models import Musteri
# from openpyxl import load_workbook
# import requests
# import json

# users = User.query.all()
# total = 0
# for user in users:
#     total += user.kirkbes_tahsilat
#
# print(total)

#
# siparis = Siparis(proje_no='1105190540müsa', musteri_adi='Bursareel Evleri Site Yönetimi',
#                          siparis_tutari=6098.80, user_id=18, siparis_son_durum='Teslim Edildi - Müşteri', son_odeme_tarihi='2019-12-31',
#                          isin_alinma_tarihi='2019-07-22', evrak_cikis_tarihi='2019-09-11')
# db.session.add(siparis)
# db.session.commit()

# user = User.query.get(8)
# user.toplam_siparis_tutari += 3000
# db.session.commit()
#






# response = requests.get("https://api.parasut.com/v4/235251/contacts/11230281", headers={
#     'Authorization': 'Bearer ' + '9d42ce3a14dee556088240c0da5abde3a5b6d2d7981a48ff909e76aecc3c4013'})
# print(response)
# musteri = response.json()
# print(musteri['data'])

# user = User.query.get(15)
# sample = [musteri.id for musteri in user.musteriler]
# print(db.session.query(Odeme).filter(Odeme.musteri_id.in_(sample)).group_by(Odeme.create_date).all())
# gunluk_veriler = db.session.query(Odeme.create_date, func.sum(Odeme.tutar)).filter(Odeme.musteri_id.in_(sample)).order_by(Odeme.create_date).group_by(Odeme.create_date).all()
#
# for veri in gunluk_veriler:
#     print(veri[0])
#     print(veri[1])

#
# musteri_list = [2092, 2036, 2189, 2208, 2248, 2325, 2415, 2732, 2783, 2846, 3002, 3056, 3103, 3674, 3248, 3343, 3626,
#                 3730, 2952]
#
# start_date = date(2019, 2, 25)
# pazar_date = date(2019, 1, 20)
# index = 1
# while index < 7:
#     if start_date != pazar_date:
#         for musteri in musteri_list:
#             odeme = Odeme(musteri_id=musteri, tutar=0.0, create_date=start_date)
#             db.session.add(odeme)
#             db.session.commit()
#     elif start_date == pazar_date:
#         pazar_date = pazar_date + timedelta(days=7)
#     index += 1
#     start_date = start_date + timedelta(days=1)

# musteriler = Musteri.query.all()
# for musteri in musteriler:
#     musteri.tahsilat = 0
#     db.session.commit()
#


# excel = load_workbook("excel.xlsx")
# sheet = excel.active
# i = 2
# while i <= sheet.max_row:
#     if sheet["F" + str(i)].value != None:
#         musteri = Musteri.query.filter_by(isim=sheet["C" + str(i)].value).first()
#         musteri.tahsilat += sheet["F" + str(i)].value
#         user = User.query.get(musteri.user_id)
#         user.kirkbes_tahsilat += sheet["F" + str(i)].value
#         print(user.kirkbes_tahsilat, musteri.tahsilat, i)
#         odeme = Odeme(musteri_id=musteri.id,tutar=sheet["F" + str(i)].value, create_date=sheet["B" + str(i)].value)
#         db.session.add(odeme)
#         db.session.commit()
#         i += 1

# excel = load_workbook("excel.xlsx")
# sheet = excel.active
# i = 2
# while i <= sheet.max_row:
#     musteri = Musteri.query.filter_by(isim = sheet["C" + str(i)].value).first()
#
#     if musteri is None:
#         print(i)
#     i += 1
#
# musteriler = Musteri.query.all()
# for musteri in musteriler:
#     musteri.tahsilat = 0
#     db.session.commit()

# musteriler = Musteri.query.all()
# i = 0
# for musteri in musteriler:
#     user = User.query.get(musteri.user_id)
#     user.kirkbes_tahsilat += musteri.tahsilat
#     db.session.commit()
#     print(i)
#     i += 1
#
#
# excel = load_workbook("merve 4kecili ocak ayı guncel odul-ceza.xlsx")
# sheet = excel.active
# index = 2
# siparisler = Siparis.query.all()
# odemeler = Odeme.query.filter_by(extract('month', Odeme.create_date ) == 1).all()
#
# toplamocak=0
# toplamsubat=0
# for siparis in siparisler:
#     for odeme in siparis.odeme:
#         user= User.query.get(siparis.user_id)
#         sheet["A" +str(index)].value = odeme.create_date
#         sheet["B" + str(index)].value = odeme.tutar
#         sheet["C" + str(index)].value = siparis.musteri_adi
#         sheet["D" + str(index)].value = user.name
#         sheet["E" + str(index)].value = siparis.isin_alinma_tarihi
#         sheet["F" + str(index)].value = siparis.son_odeme_tarihi
#         print(index)
#         index += 1
#
# #

# guncel_musteri = Workbook()
# sheet = guncel_musteri.active
# siparisler = Siparis.query.filter(extract('month', Siparis.son_odeme_tarihi) == 12).all()
# i=2
# for siparis in siparisler:
#     user = User.query.get(siparis.user_id)
#     sheet["A" + str(i)].value = user.name
#     sheet["B" + str(i)].value = siparis.musteri_adi
#     sheet["C" + str(i)].value = siparis.proje_no
#     sheet["D" + str(i)].value = siparis.siparis_tutari
#     sheet["E" + str(i)].value = siparis.tahsilat
#     sheet["F" + str(i)].value = siparis.son_odeme_tarihi
#     i+=1
#
# guncel_musteri.save("Aralık Ayı Tahsilat Portalı Duplicate Icerenler.xlsx")
# import pandas as pd
# excel = pd.read_excel("Aralık Ayı Tahsilat Portalı Duplicate Icerenler.xlsx")
# excel = excel.duplicated(subset=['sipariş kodu'], keep='first')
# excel.to_excel('Aralık Ayı Tahsilat Portalı Duplicatedler.xlsx', index=False)
#

#
#
# # AY SONU ÖDEME ALINAMAYAN İŞLERİ LİSTELER
# guncel_devreden = load_workbook("fst mdasdayıs.xlsx")
# sheet = guncel_devreden.active
# i = 2
# siparisler = Siparis.query.filter(extract('month', Siparis.son_odeme_tarihi) == 5).all()
# for siparis in siparisler:
#     user = User.query.get(siparis.user_id)
#     print(siparis.musteri_adi)
#     if siparis.tahsilat != siparis.siparis_tutari:
#         sheet["A" + str(i)].value = user.name
#         sheet["B" + str(i)].value = siparis.musteri_adi
#         sheet["C" + str(i)].value = siparis.proje_no
#         sheet["D" + str(i)].value = siparis.siparis_tutari
#         sheet["E" + str(i)].value = siparis.tahsilat
#         i +=1
# guncel_devreden.save("fst masdasdyıs.xlsx")
#
#
# # ÖDEME ALINAMAYAN İŞLERİN MÜŞTERİLERİNİ VE BORÇLARINI TUĞBA KILIÇ'A AKTARMAK İÇİN
# # guncel_devreden = load_workbook("ocak-ve-subat-ayi-odeme-alinamayan-isler.xlsx")
# # sheet = guncel_devreden.active
# # i=2
# # index = 0
# # musteriler = Musteri.query.all()
# # print(sheet.max_row)
# # while i<= sheet.max_row:
# #     for musteri in musteriler:
# #         if sheet["B" + str(i)].value == musteri.isim:
# #             musteri.bakiye += sheet["C" + str(i)].value
# #             index +=1
# #             print(musteri.isim)
# #     i += 1
# # print(index)
#
# #
# # excel.save("merve kecili 4ocak ayı guncel odul-ceza.xlsx")
# # excel = load_workbook("indirimler.xlsx")
# # sheet = excel.active
# # i = 1
# # while i <= sheet.max_row:
# #     musteri = Musteri.query.filter_by(isim=sheet["C" + str(i)].value).first()
# #     indirim_tutari = sheet["F" + str(i)].value
# #     user = User.query.get(musteri.user_id)
# #     musteri.bakiye -= indirim_tutari
# #     user.kirkbes_bakiye -= indirim_tutari
# #     print(musteri.isim, musteri.bakiye, user.kirkbes_bakiye, i)
# #     print(sheet["C" + str(i)].value, musteri.bakiye, user.kirkbes_bakiye, i)
# #     indirim = Indirim(musteri_id=musteri.id, indirim_tutari=sheet["F" + str(i)].value, create_date=sheet["B" + str(i)].value)
# #     db.session.add(indirim)
# #     db.session.commit()
# #     i += 1
# #
# #
# # db.create_all()
# # db.create_all()
# #
#
# # excel = load_workbook("4.xlsx")
# # sheet = excel.active
# # musteriler=Musteri.query.all()
# # i = 1
# #
# # for musteri in musteriler:
# #     siparis = Siparis.query.filter_by(musteri_adi=sheet["C" + str(i)].value).first()
# #         user = User.query.get(siparis.user_id)
# #         user.toplam_siparis_tahsilati += sheet["B" + str(i)].value
# #     siparis.kalan_miktar -= sheet["B" + str(i)].value
# #
#
#
# # musteriler=Musteri.query.all()
# # for musteri in musteriler:
# #     if (musteri.bakiye - musteri.tahsilat) < 0:
# #         mus = musteri.isim
# #         siparis=Siparis.query.filter_by(musteri_adi=mus).first()
# #         print(siparis.musteri_adi)
#
# # excel.save("4.xlsx")
#
# # siparis = Siparis.query.filter_by(musteri_adi=musteri).first()
# # user = User.query.get(siparis.user_id)
# # siparis.siparis_tutari -= eklenecek_tutar
# # user.toplam_siparis_tahsilati += eklenecek_tutar
# # db.session.commit()
#
# AYLIK OLARAK SİPARİŞLERİ EKLER VE USER TABLOSUNDA GEREKLİ YERLERİ ONA GÖRE ARTTIRIR
# excel = load_workbook("ağustos ayı tahsilat portalı.xlsx")
# sheet = excel.active
# i = 2
# while i <= 287:
#     print(i)
#     user = User.query.filter_by(name=sheet["F" + str(i)].value).first()
#     siparis = Siparis(proje_no=sheet["B" + str(i)].value, musteri_adi=sheet["A" + str(i)].value,
#                          siparis_tutari=sheet["H" + str(i)].value, user_id=user.id, siparis_son_durum=sheet["C" + str(i)].value, son_odeme_tarihi=sheet["E" + str(i)].value,
#                          isin_alinma_tarihi=sheet["G" + str(i)].value, evrak_cikis_tarihi=sheet["D" + str(i)].value, onceki_aydan_kalan=0)
#     print(i)
#     db.session.add(siparis)
#     db.session.commit()
#     i += 1


# # users = User.query.all()
# users = User.query.all()
# siparisler = Siparis.query.filter(extract('month', Siparis.son_odeme_tarihi) == 8 ).all()
# sayac = 0
# for user in users:
#     for siparis in user.siparisler:
#         if user.id == siparis.user_id:
#             user.toplam_siparis_tutari += siparis.siparis_tutari
#             sayac += 1
#             print(sayac)
#             db.session.commit()
# # tum_devreden = load_workbook("tüm devreden müşteriler.xlsx")
# # devreden_sheet = tum_devreden.active
# # musteriler = Musteri.query.filter(Musteri.odemeler == None)
# # i=2
# # for musteri in musteriler:
# #     # odeme = Odeme.query.get(musteri.odemeler)
# #     # for ode in odeme:
# #     user = User.query.get(musteri.user_id)
# #     devreden_sheet["A" + str(i)].value = user.name
# #     devreden_sheet["B" + str(i)].value = musteri.isim
# #     devreden_sheet["C" + str(i)].value = musteri.bakiye
# #     devreden_sheet["D" + str(i)].value = musteri.tahsilat
# #     print(i)
# #     i += 1
# # tum_devreden.save("tüm devreden müşteriler.xlsx")
#
#
# # guncel = load_workbook("1-28 4.xlsx")
# # guncel_sheet = guncel.active
# # temp = 0
# # temp2 = 0
# # i=777
# # j=2
# # while i<=devreden_sheet.max_row:
# #     while j<=guncel_sheet.max_row:
# #         if devreden_sheet["B" + str(i)].value == guncel_sheet["C" + str(j)].value:
# #             print("VAR")
# #             print("*********************************")
#             temp2 += int(guncel_sheet["F" + str(j)].value)
#         devreden_sheet["G" + str(i)].value = temp2
#         j +=1
#     temp2=0
#     print(i)
#     i +=1
#     j = 2
#
# devreden.save("devreden  bakiye  genel rapor.xlsx")
#
#
# portal_mayis = Workbook()
# portal_sheet = portal_mayis.active
# siparisler = Siparis.query.filter(extract('month', Siparis.son_odeme_tarihi) == 10 ).all()
# index =  2
# for siparis in siparisler:
#     user = User.query.get(siparis.user_id)
#     portal_sheet["A" + str(index)].value = user.name
#     portal_sheet["B" + str(index)].value = siparis.musteri_adi
#     portal_sheet["C" + str(index)].value = siparis.proje_no
#     portal_sheet["D" + str(index)].value = siparis.siparis_tutari
#     portal_sheet["E" + str(index)].value = siparis.tahsilat
#     index += 1
#
# portal_mayis.save("portal ekim ayı.xlsx")

# excel = load_workbook("vadesiz fstsiz.xlsx")
# sheet = excel.active
# crm_mayis = load_workbook("dasdasdcrm excel (2).xlsx")
# crm_sheet = crm_mayis.active
#
# index = 2
# crm = 2
# while index <= crm_sheet.max_row:
#     while crm <= sheet.max_row:
#         if str(crm_sheet["A" + str(index)].value) == str(sheet["B" + str(crm)].value):
#             sheet["E" + str(crm)].value = crm_sheet["B" + str(index)].value
#             print("burda")
#             break
#         crm += 1
#     index += 1
#     print(index)
#     crm = 2
#
# excel.save("vadesiz fstsiz.xlsx")

# excel = load_workbook("Mayıs Ayı Ödeme Alınamayan İşler.xlsx")
# sheet = excel.active
# index = 2
# siparisler = Siparis.query.filter(extract('month', Siparis.son_odeme_tarihi) == 5 ).all()
# while index <= sheet.max_row:
#     for siparis in siparisler:
#         user = User.query.get(siparis.user_id)
#         if sheet["B" + str(index)].value == str(siparis.proje_no):
#             print("burda")
#             sheet["G" + str(index)].value = siparis.tahsilat
#             sheet["H" + str(index)].value = user.name
#             break
#     print(index)
#     index += 1
#
# excel.save("Mayıs Ayı Ödeme Alınamayan İşler.xlsx")

# portal_excel = load_workbook("müşteriler ve bakiye değişimleri.xlsx")
# portal_sheet = portal_excel.active
#
# musteri_excel = load_workbook("MÜŞTERİ TÜR.xlsx")
# musteri_sheet = musteri_excel.active
#
# index = 1024
# index2 = 1383
# while index<=portal_sheet.max_row:
#     while index2<=musteri_sheet.max_row:
#         if portal_sheet["B" + str(index)].value == musteri_sheet["A" + str(index2)].value:
#             print("HEREEEE")
#             print(musteri_sheet["B" + str(index2)].value)
#             portal_sheet["H" + str(index)].value = musteri_sheet["B" + str(index2)].value
#         index2 +=1
#     print(index)
#     print("************************")
#     index +=1
#     index2 = 1383
#
# portal_excel.save("müşteriler ve bakiye değişimleri.xlsx")


# siparis = Siparis(proje_no="0205190613deka", musteri_adi="ABDİ AĞAOĞLU İNŞAAT FATİH KARATAŞ",
#                          siparis_tutari=200, user_id=6, siparis_son_durum="Teslim Edildi - Müşteri", son_odeme_tarihi="2019-10-31",
#                          isin_alinma_tarihi="2019-05-02", evrak_cikis_tarihi="2019-08-19")
# db.session.add(siparis)
# db.session.commit()
#
# excel = load_workbook("müşteriler ve bakiye değişimleri.xlsx")
# sheet = excel.active
# index = 2
# musteriler = Musteri.query.all()
# while index<=sheet.max_row:
#     for musteri in musteriler:
#         if sheet["B" + str(index)].value == musteri.isim:
#             user = User.query.get(musteri.user_id)
#             sheet["A" + str(index)].value = user.name
#             print("HEREEEEEEEEEE")
#     print(index)
#     index+=1
#
# excel.save("müşteriler ve bakiye değişimleri.xlsx")
# devreden = load_workbook("devreden  bakiye  genel rapor.xlsx")
# devreden_sheet = devreden.active
# musteriler = Musteri.query.all()
# i=2
# for musteri in musteriler:
#     while i<=devreden_sheet.max_row:
#         if musteri.isim == devreden_sheet["B" + str(i)].value:
#             print(musteri.isim)
#         i +=1
#


# excel = load_workbook("devreden  bakiye  genel rapor.xlsx")
# sheet = excel.active
# # sheet["A1"].value = "Devreden Temsilci İsmi"
# # sheet["B1"].value = "Müşteri Adı"
# # sheet["C1"].value = "Toplam Devreden Bakiyesi"
# # sheet["D1"].value = "Ödeme Tarihi"
# # sheet["E1"].value = "Ödeme Tutarı"
# # sheet["F1"].value = "14-31 Ocak Arası Yapılan Tahsilat"
# # sheet["G1"].value = "1-28 Şubddat Arası Yapılan Tahsilat"
# i = 2
# temp = 0
# # ocak_start = date(year=2019,month=1,day=14)
# # ocak_end = date(year=2019,month=1,day=31)
# musteriler = Musteri.query.all()
# siparisler = Siparis.query.all()
# sayac = 1
# temp = 0
# tempsubat =0
# for musteri in musteriler:
#     user = User.query.get(musteri.user_id)
#     for odeme in musteri.odemeler:
#         if odeme.create_date.month == 1 and odeme.create_date.day >= 14 and odeme.create_date.day <=31:
#             sheet["A" + str(i)].value = user.name
#             sheet["B" + str(i)].value = musteri.isim
#             sheet["C" + str(i)].value = musteri.bakiye
#             sheet["D" + str(i)].value = odeme.create_date
#             sheet["E" + str(i)].value = odeme.tutar
#             temp += odeme.tutar
#         elif odeme.create_date.month == 2 and odeme.create_date.day >= 1 and odeme.create_date.day <= 28:
#             sheet["A" + str(i)].value = user.name
#             sheet["B" + str(i)].value = musteri.isim
#             sheet["C" + str(i)].value = musteri.bakiye
#             sheet["D" + str(i)].value = odeme.create_date
#             sheet["E" + str(i)].value = odeme.tutar
#             tempsubat += odeme.tutar
#         sheet["F" + str(i)].value = temp
#         sheet["G" + str(i)].value = tempsubat
#         temp = 0
#         tempsubat=0
#         i+=1
#         print(sayac)
#         sayac+=1
# excel.save("devreden  bakiye  genel rapor.xlsx")

#
# excel = load_workbook("de55vreden-mart.xlsx")
# sheet = excel.active
# i=2
# temp=1
# musteriler=Musteri.query.all()
# for musteri in musteriler:
#     user=User.query.get(musteri.user_id)
#     for odeme in musteri.odemeler:
#         sheet["A" + str(i)].value = user.name
#         sheet["B" + str(i)].value = musteri.isim
#         sheet["C" + str(i)].value = musteri.bakiye
#         sheet["D" + str(i)].value = odeme.create_date
#         sheet["E" + str(i)].value = odeme.tutar
#         print(temp)
#         temp+=1
#         i+=1
#
# excel.save("devre4den-mart.xlsx")
#
# for musteri in musteriler:
#     # for siparis in siparisler:
#         # if musteri.isim == siparis.musteri_adi:
#     user = User.query.get(musteri.user_id)
#     odeme = Odeme.query.filter(Odeme.create_date <= ocak_end).filter(Odeme.create_date>= ocak_start).all()
#     for ode in musteri.odemeler:
#         temp += odeme.tutar
#         # sheet.append([user.name, musteri.isim, musteri.bakiye, odeme.create_date, odeme.tutar])
#         sheet["A" + str(i)].value = user.name
#         sheet["B" + str(i)].value = musteri.isim
#         sheet["C" + str(i)].value = musteri.bakiye
#         sheet["D" + str(i)].value = odeme.create_date
#         sheet["E" + str(i)].value = odeme.tutar
#         # print(user.name)
#         # print(musteri.isim)
#         # print(musteri.bakiye)
#         # print(odeme.create_date)
#         # print(odeme.tutar)
#     # sheet.append([temp, musteri.tahsilat - temp])
#     # print(temp)
#     # print(musteri.tahsilat - temp)
#     sheet["F" + str(i)].value = temp
#     sheet["G" + str(i)].value = musteri.tahsilat - temp
#     print("****************************************")
#     temp = 0
#     i +=1

# excel.save("devreden  bakiye  genel rapor.xlsx")

# ödeme girilen siparişleri listeler
# guncel_siparisler = load_workbook("mayıs ayı ödeme girilen işler-temsilcileri.xlsx")
# guncel_sheet = guncel_siparisler.active
# siparisler = Siparis.query.filter(extract('month', Siparis.son_odeme_tarihi) == 5 ).all()
# i=2
# for siparis in siparisler:
#     user = User.query.get(siparis.user_id)
#     for odeme in siparis.odeme:
#         guncel_sheet["A" + str(i)].value = siparis.musteri_adi
#         guncel_sheet["B" + str(i)].value = siparis.siparis_tutari
#         guncel_sheet["C" + str(i)].value = odeme.create_date
#         guncel_sheet["D" + str(i)].value = odeme.tutar
#         guncel_sheet["E" + str(i)].value = user.name
#         i+=1
# guncel_siparisler.save("mayıs ayı ödeme girilen işler-temsilcileri.xlsx")


# aylık tüm siparişleri listeler
# wb = Workbook()
# sheet = wb.active
# son_odeme_ay = 2
# son_odeme_yil = 2020
# siparisler = Siparis.query.filter(and_(extract('month', Siparis.son_odeme_tarihi)  == son_odeme_ay, extract('year', Siparis.son_odeme_tarihi) == son_odeme_yil)).all()
# index = 2
# for siparis in siparisler:
#     print(siparis.user_id)
#     user = User.query.get(siparis.user_id)
#     print(user.name)
#     sheet["A" + str(index)].value = user.name
#     sheet["B" + str(index)].value = siparis.musteri_adi
#     sheet["C" + str(index)].value = siparis.proje_no
#     sheet["D" + str(index)].value = siparis.siparis_tutari
#     sheet["E" + str(index)].value = siparis.tahsilat
#     sheet["F" + str(index)].value = siparis.son_odeme_tarihi
#     sheet["G" + str(index)].value = siparis.siparis_son_durum
#     index += 1
#     print(index)
#
# wb.save("Şubaddt 2020 Tahsilat Portalı Raporu.xlsx")


# import pandas as pd
# excel = pd.read_excel("vadesi geçmiş siparişlerr.xlsx")
# sheet = excel.active
# excel = excel.drop_duplicates(subset=['Müşteri Adı'], keep='last', inplace=False)
# excel.to_excel("Vadesi Geçmiş Müşteriler ( 24.09.2019 ).xlsx")



# DEVREDEN BAKİYE RAPORU
# excel = load_workbook("devreden müşteri.xlsx")
# sheet = excel.active
# user = User.query.all()
# musteriler = Musteri.query.all()
# i = 0
# for musteri in musteriler:
#     user = User.query.get(musteri.user_id)
#     sheet.append(
#         [user.name, musteri.isim, musteri.bakiye, musteri.tahsilat])
#     print(user.name + " " + musteri.isim + "   " + str(i))
#     i += 1
#
# excel.save("devreden müşteri.xlsx")

# guncel_musteri = load_workbook("müşteriler ve güncel bakiyeleri.xlsx")
# sheet = guncel_musteri.active
# index = 2
# while in
# print(1)
# user = User(email="ekb17@sehatek.com.tr",role="Employee",name="Dilara Seyrekbasan",password=bcrypt.generate_password_hash("dse147852o").decode("utf-8"),shortcode="dise")

# user = User(email="ekb15@sehatek.com.tr",role="Employee",name="Fatma Nur İpek",password=bcrypt.generate_password_hash("123456789t").decode("utf-8"),shortcode="faip")
# user = User(email="ekb7@sehatek.com.tr",role="Employee",name="Eda İpek",password=bcrypt.generate_password_hash("74EDsOkL59").decode("utf-8"),shortcode="edip")
# user = User(email="ekb5@sehatek.com.tr",role="Employee",name="Gülbahar Koç",password=bcrypt.generate_password_hash("123654g***").decode("utf-8"),shortcode="güko")
# user = User(email="ekb14@sehatek.com.tr",role="Employee",name="Esra Alagöz",password=bcrypt.generate_password_hash("Ca4hqo9C00").decode("utf-8"),shortcode="esal")
# user = User(email="ekb23@sehatek.com.tr",role="Employee",name="Nurseda Kılıç",password=bcrypt.generate_password_hash("E05jp6Gq6c").decode("utf-8"),shortcode="nukı")
#
# user = User(email="ekb9@sehatek.com.tr",role="Employee",name="Gonca Ecrin Odabaş",password=bcrypt.generate_password_hash("74EDsOkL59").decode("utf-8"),shortcode="goecod")
# user = User(email="ekbdestek@sehatek.com.tr",role="Employee",name="Gülbin Genç",password=bcrypt.generate_password_hash("89dtkVLS21").decode("utf-8"),shortcode="güge")
# user = User(email="ekb16@sehatek.com.tr",role="Employee",name="Tuğçe Albayrak",password=bcrypt.generate_password_hash("58dkcBYTS1").decode("utf-8"),shortcode="tual")
# user = User(email="ekb19@sehatek.com.tr",role="Employee",name="Suna Koyuncu",password=bcrypt.generate_password_hash("25dOsmFds5").decode("utf-8"),shortcode="suko")
# user = User(email="ekb6@sehatek.com.tr",role="Employee",name="Seher Demirtaş",password=bcrypt.generate_password_hash("ta58LKD4sr").decode("utf-8"),shortcode="seda")
#
# user = User(email="ekb10@sehatek.com.tr",role="Employee",name="Ayşe Gebeş",password=bcrypt.generate_password_hash("58dkcBYTS1").decode("utf-8"),shortcode="ayge")
# user = User(email="ekb20@sehatek.com.tr",role="Employee",name="Gamze Göçer Özlü",password=bcrypt.generate_password_hash("25dOsmFds5").decode("utf-8"),shortcode="gagö")


# db.session.add(user)
# db.session.commit()
#
# print(2)
# # # #
# user = User(email="ekb22@sehatek.com.tr",role="Employee",name="Ayşenur Tabak",password=bcrypt.generate_password_hash("VvXH64FFK3").decode("utf-8"),shortcode="ayta")
# user = User(email="ekb25@sehatek.com.tr",role="Employee",name="Tuba Çelik",password=bcrypt.generate_password_hash("123654t***").decode("utf-8"),shortcode="tuçe")
#

# excel = load_workbook("sahacılar.xlsx")
# sheet = excel.active
# i = 7
# while i<=44:
#     user = User.query.filter_by(name=sheet["E" + str(i)].value).first()
#     print(user.id)
#     siparis = Siparis(proje_no=sheet["B" + str(i)].value, musteri_adi=sheet["A" + str(i)].value,
#                             siparis_tutari=sheet["G" + str(i)].value,siparis_son_durum=sheet["C" + str(i)].value, son_odeme_tarihi=sheet["D" + str(i)].value,
#                              isin_alinma_tarihi=sheet["F" + str(i)].value, user_id=user.id)
#     print(i)
#     db.session.add(siparis)
#     db.session.commit()
#     i += 1

#
# excel = load_workbook("merve_74kecili_edit.xlsx")
# sheet = excel.active
# i = 755
# while i<=810:
#     user = User.query.filter_by(name=sheet["F" + str(i)].value).first()
#     musteri = Musteri.query.get(musteri.user_id)
#     user

# excel = load_workbook("14-31 eksi bakiyesiz.xlsx")
# sheet = excel.active
# siparisler = Siparis.query.all()
# i = 2
# for siparis in siparisler:
#     print(siparis.musteri_adi)
#     user = User.query.get(siparis.user_id)
#     sheet["A" + str(i)].value = user.name
#     sheet["B" + str(i)].value = siparis.proje_no
#     sheet["C" + str(i)].value = siparis.musteri_adi
#     sheet["D" + str(i)].value = siparis.siparis_tutari
#     sheet["E" + str(i)].value = siparis.tahsilat
#     sheet["F" + str(i)].value = siparis.siparis_son_durum
#     sheet["G" + str(i)].value = siparis.isin_alinma_tarihi
#     sheet["H" + str(i)].value = siparis.son_odeme_tarihi
#     i +=1
# print(i)
#
# excel.save("14-31 eksi bakiyesiz.xlsx")


# musteri = Musteri(isim="Merkez Kent Apartmanı Yılmaz Bey",telefon="05555555555",bakiye=54,parasut_no="11234488",user_id=29)
# db.session.add(musteri)
# db.session.commit()

# siparis = Siparis(musteri_adi="NURŞEN ŞEN",proje_no="1012190644sege",siparis_tutari=200,
#                   son_odeme_tarihi='30/01/2020',evrak_cikis_tarihi='08/05/2019',user_id=9,siparis_son_durum='Teslim Edildi - Müşteri')
# db.session.add(siparis)
# db.session.commit()

# user = User(email="bilgiislem@sehatek.com.tr",role="Employee",name="Duygu Evrim Odabaş",password=bcrypt.generate_password_hash("sD428OEh26").decode("utf-8"),shortcode="deod")
# db.session.add(user)
# db.session.commit()

# AYLIK OLARAK SİPARİŞ TUTARI VE TAHSİLAT MİKTARINI TEMSİLCİ TABLOSU İSİMLİ TABLOYA ATAR
# users = User.query.all()
# month = datetime.now().month
# siparisler = Siparis.query.filter(extract('month', Siparis.son_odeme_tarihi) == 7 ).all()
# for user in users:
#     temsilci_tablosu = TemsilciOranlari(user_id=user.id,siparis_date='2019-11-31',toplam_siparis_miktari=user.toplam_siparis_tutari,toplam_siparis_tahsilati=user.toplam_siparis_tahsilati)
#     db.session.add(temsilci_tablosu)
#     db.session.commit()

# mart_ayi_odeme_alinamayan = load_workbook("odeme-alinamayan-mart.xlsx")
# sheet = mart_ayi_odeme_alinamayan.active
# i=2
# siparisler = Siparis.query.filter(extract('month', Siparis.son_odeme_tarihi) == 3 ).all()
# for siparis in siparisler:
#     user = User.query.get(siparis.user_id)
#     if(siparis.tahsilat != siparis.siparis_tutari):
#         sheet["G" + str(i)].value = user.name
#         sheet["A" + str(i)].value = siparis.musteri_adi
#         sheet["B" + str(i)].value = siparis.siparis_tutari
#         sheet["D" + str(i)].value = siparis.tahsilat
#         i +=1
# mart_ayi_odeme_alinamayan.save("odeme-alinamayan-mart.xlsx")


# KONTOLLLL
# OSMANOĞLU MİMARLIK-
# ÖZSOY YAPI UYGULAMA İNŞ.MAK.MİM.SAN.TİC-
# Yusuf Erkan-
# Kartepe Yapı Denetim Uğur Bey
# ÖNDER SİTESİ YÖNETİMİ

# subat_ayi_rapor_excel = load_workbook("mart-ayı-rapor.xlsx")
# subat_ayi_sheet = subat_ayi_rapor_excel.active
# month = datetime.now().month
# siparisler = Siparis.query.filter(extract('month', Siparis.son_odeme_tarihi) == 3 ).all()
#
# i=2
# for siparis in siparisler:
#     user = User.query.get(siparis.user_id)
#     for odeme in siparis.odeme:
#         subat_ayi_sheet["G" + str(i)].value = odeme.create_date
#     subat_ayi_sheet["A" + str(i)].value = user.name
#     subat_ayi_sheet["B" + str(i)].value = siparis.musteri_adi
#     subat_ayi_sheet["C" + str(i)].value = siparis.proje_no
#     subat_ayi_sheet["D" + str(i)].value = siparis.siparis_son_durum
#     subat_ayi_sheet["E" + str(i)].value = siparis.siparis_tutari
#     subat_ayi_sheet["F" + str(i)].value = siparis.tahsilat
#     subat_ayi_sheet["H" + str(i)].value = siparis.isin_alinma_tarihi
#     subat_ayi_sheet["I" + str(i)].value = siparis.son_odeme_tarihi
#     i += 1
#
# subat_ayi_rapor_excel.save("mart-ayı-rapor.xlsx")
#


# toplam=0
# i=0
# siparisler = Siparis.query.filter_by(user_id=6).filter(extract('month', Siparis.son_odeme_tarihi) == 3).all()
# for siparis in siparisler:
#     print(siparis)
#     i +=1
#     toplam+=siparis.tahsilat
# print(i)
# print(toplam)
#


# #
# siparis = Siparis(proje_no='2907190534deka',musteri_adi='CG Elektrik Mühendislik Cüneyt Bey',siparis_tutari=600,son_odeme_tarihi='2019-10-31',isin_alinma_tarihi='2019-07-29',user_id=6,siparis_son_durum='Teslim Edildi - Müşteri',evrak_cikis_tarihi='2019-08-02')
#
# db.session.add(siparis)
# db.session.commit()
#
#
# Aylık odemeleri cekmek icin
# odeme_tablosu = Odeme.query.filter(extract('month',Odeme.create_date) == 2 ).all()
# for odeme in odeme_tablosu:
#     print(odeme.musteri_id)
#     musteri = Musteri.query.get(odeme.musteri_id)
#     user = User.query.get(musteri.user_id)
#     print(musteri.isim + "  " + user.name)

#
# crm_excel = load_workbook("14-31 teslim 4.xlsx")
# crm_sheet = crm_excel.active
#
# portal_delete_excel = load_workbook("portal kontrol.xlsx")
# portal_delete_sheet = portal_delete_excel.active
#
# portala_eklenecek_excel = load_workbook("teslim edildi.xlsx")
# portala_eklenecek_sheet = portala_eklenecek_excel.active
#
# k = 2
# i = 2
# j = 2
# while i<=crm_sheet.max_row:
#     while j<=portal_delete_sheet.max_row:
#         if crm_sheet["B" + str(i)].value == portal_delete_sheet["B" + str(j)].value:
#             print(portal_delete_sheet["B" + str(j)].value + str(i))
#             portala_eklenecek_sheet["A" + str(k)].value = portal_delete_sheet["B" + str(j)].value
#             portala_eklenecek_sheet["B" + str(k)].value = portal_delete_sheet["A" + str(j)].value
#             portala_eklenecek_sheet["C" + str(k)].value = portal_delete_sheet["C" + str(j)].value
#             portala_eklenecek_sheet["D" + str(k)].value = portal_delete_sheet["D" + str(j)].value
#             portala_eklenecek_sheet["E" + str(k)].value = portal_delete_sheet["E" + str(j)].value
#             portala_eklenecek_sheet["F" + str(k)].value = crm_sheet["C" + str(i)].value
#             portala_eklenecek_sheet["G" + str(k)].value = portal_delete_sheet["G" + str(j)].value
#             portala_eklenecek_sheet["H" + str(k)].value = portal_delete_sheet["H" + str(j)].value
#             k += 1
#         j += 1
#     i += 1
#     j=2
#
# portala_eklenecek_excel.save("teslim edildi.xlsx")

# evrak_excel = load_workbook("evrak çıkış.xlsx")
# evrak_sheet = evrak_excel.active
#
# durum_excel = load_workbook("durum.xlsx")
# durum_sheet = durum_excel.active
#
# yeni_excel = load_workbook("yeni.xlsx")
# yeni_sheet = yeni_excel.active
#
#
# i = 2
# k = 2
# j = 2
# while i<=evrak_sheet.max_row:
#     while k<=durum_sheet.max_row:
#         if evrak_sheet["B" + str(i)].value == durum_sheet["B" + str(k)].value:
#             yeni_sheet["A" + str(j)].value = durum_sheet["B" + str(k)].value
#             print(evrak_sheet["B" + str(i)].value)
#             j += 1
#         k +=1
#     i += 1
#     k = 2
#     print(i)
#
# yeni_excel.save("yeni.xlsx")

# # ODEMESİ YAPILMIS İSLERİ BULUYOR
# crm = load_workbook("ağustos ayı sipdariş lsdsdistesi ( ofis ).xlsx")
# crm_rapor_sheet = crm.active
#
# parasut_rapor = load_workbook("sadasdagustos icin parasut.xlsx")
# parasut_rapor_sheet = parasut_rapor.active
#
# yeni_excel = load_workbook("odemesi yapilmis isler.xlsx")
# yeni_sheet = yeni_excel.active
# k = 2
# sayac = 0
# j = 2
# i=2
#
# while i <= crm_rapor_sheet.max_row:
#     while k <= parasut_rapor_sheet.max_row:
#         if str(crm_rapor_sheet["A" + str(i)].value) == str(parasut_rapor_sheet["C" + str(k)].value) and str(crm_rapor_sheet["H" + str(i)].value) == str(parasut_rapor_sheet["F" + str(k)].value):
#             print(parasut_rapor_sheet["C" + str(k)].value + "   " + str(sayac))
#             sayac += 1
#             yeni_sheet["A" + str(j)].value = crm_rapor_sheet["B" + str(i)].value
#             yeni_sheet["B" + str(j)].value = crm_rapor_sheet["A" + str(i)].value
#             yeni_sheet["C" + str(j)].value = crm_rapor_sheet["H" + str(i)].value
#             yeni_sheet["D" + str(j)].value = parasut_rapor_sheet["F" + str(k)].value
#             j +=1
#         k += 1
#     i += 1
#     k=2
#
# yeni_excel.save("odemesi yapilmis isler.xlsx")
# # i = 2
# while i <= crm_rapor_sheet.max_row:
#     while k <= parasut_rapor_sheet.max_row:
#         if crm_rapor_sheet["A" + str(i)].value == parasut_rapor_sheet["B" + str(k)].value and crm_rapor_sheet[
#             "H" + str(i)].value == parasut_rapor_sheet["D" + str(k)].value:
#             print(
#                 parasut_rapor_sheet["B" + str(k)].value + str(parasut_rapor_sheet["D" + str(k)].value) + "     " + str(
#                     j))
#             yeni_sheet["A" + str(j)].value = crm_rapor_sheet["A" + str(i)].value
#             yeni_sheet["B" + str(j)].value = crm_rapor_sheet["B" + str(i)].value
#             yeni_sheet["C" + str(j)].value = crm_rapor_sheet["H" + str(i)].value
#             yeni_sheet["E" + str(j)].value = parasut_rapor_sheet["D" + str(k)].value
#             j += 1
#         k += 1
#     i += 1
#     k = 2
#
# yeni_excel.save("odemesi-yapilmis-isler.xlsx")

# evrak_excel = load_workbook("evrak çıkışş.xlsx")
# evrak_sheet = evrak_excel.active
#
# durum_excel = load_workbook("durum.xlsx")
# durum_sheet = durum_excel.active
#
# yeni_excel = load_workbook("yeni.xlsx")
# yeni_sheet = yeni_excel.active
#
#
# i=2
# j=2
# while i<= evrak_sheet.max_row:
#     while j<= durum_sheet.max_row:
#         if str(evrak_sheet["B" + str(i)].value) == str(durum_sheet["B" + str(j)].value):
#             evrak_sheet.delete_rows(i, 1)
#         j += 1
#     i += 1
#     j = 2
#
# evrak_excel.save("evrak çıkışş.xlsx")

# 2 EXCEL ARASINDA ORTAK OLMAYAN SATIRLARI BULUYOR
# evrak_excel = load_workbook("evrak çıkış.xlsx")
# evrak_sheet = evrak_excel.active
#
# durum_excel = load_workbook("durum.xlsx")
# durum_sheet = durum_excel.active
#
# i =2
# j=2
# sayac = 0
# while i<=evrak_sheet.max_row:
#     while j<=durum_sheet.max_row:
#         if str(evrak_sheet["B" + str(i)].value) != str(durum_sheet["B" + str(j)].value):
#             sayac += 1
#         j +=1
#     print(sayac)
#     print(i)
#     print("**************************")
#     i += 1
#     j = 2
#     sayac = 0
#


# TEMSİLCİLERE AİT DEVREDEN MÜŞTERİLERİN HEPSİ TUĞBA KILIÇ'A AKTARILACAK

# musteriler = Musteri.query.all()
# for musteri in musteriler:
#     print(musteri.bakiye)
#     eski_user = User.query.get(musteri.user_id)
#     print(eski_user.name)
#     yeni_user = User.query.get(int(21))
#     print(yeni_user.name)
#     musteri.user_id = int(21)
#     eski_user.kirkbes_bakiye -= (musteri.bakiye - musteri.tahsilat)  kalan bakiyeyi aktarması için
#     print(yeni_user.kirkbes_bakiye)
#     print(yeni_user.kirkbes_tahsilat)
#     yeni_user.kirkbes_bakiye += (musteri.bakiye - musteri.tahsilat)  kalan bakiyeyi aktarması için
#     print(yeni_user.kirkbes_bakiye)
#     print(yeni_user.kirkbes_tahsilat)
#     print("****************************************************************************************")
#     print("****************************************************************************************")
#     print("****************************************************************************************")
# delete
# mart_portal = load_workbook("mart ayhı excel.xlsx")
# mart_sheet = mart_portal.active
# siparisler = Siparis.query.all()
# i = 2
# while i<=83:
#     for siparis in siparisler:
#         if mart_sheet["B" + str(i)].value == siparis.proje_no:
#             print(str(i) + "        " + siparis.proje_no)
#     i += 1

# AYLIK OLARAK SAHACILARIN MÜŞTERİLERİNİ TEMSİLCİLERİN HEDEFİNE EKLEMEK İÇİN
# saha_excel = load_workbook("şudbat tahsilat portalı siparişler saha.xlsx")
# saha_sheet = saha_excel.active
# index = 211
# while index <= saha_sheet.max_row:
#     temsilci = saha_sheet["F" + str(index)].value
#     print(temsilci)
#     print(index)
#     if temsilci == 'Mehmet Saygın':
#         siparis = Siparis(proje_no=saha_sheet["B" + str(index)].value, musteri_adi=saha_sheet["A" + str(index)].value,
#                           siparis_tutari=saha_sheet["H" + str(index)].value, user_id=49,
#                           siparis_son_durum=saha_sheet["C" + str(index)].value,
#                           son_odeme_tarihi=saha_sheet["E" + str(index)].value,
#                           isin_alinma_tarihi=saha_sheet["G" + str(index)].value,
#                           evrak_cikis_tarihi=saha_sheet["D" + str(index)].value, onceki_aydan_kalan=1)
#         db.session.add(siparis)
#         db.session.commit()
#         user = User.query.filter(User.id == 49).first()
#         user.toplam_siparis_tutari += saha_sheet["H" + str(index)].value
#         db.session.add(user)
#         db.session.commit()
#         print("burda")
#     if temsilci == 'İlhan Kuru':
#         siparis = Siparis(proje_no=saha_sheet["B" + str(index)].value, musteri_adi=saha_sheet["A" + str(index)].value,
#                           siparis_tutari=saha_sheet["H" + str(index)].value, user_id=49,
#                           siparis_son_durum=saha_sheet["C" + str(index)].value,
#                           son_odeme_tarihi=saha_sheet["E" + str(index)].value,
#                           isin_alinma_tarihi=saha_sheet["G" + str(index)].value,
#                           evrak_cikis_tarihi=saha_sheet["D" + str(index)].value, onceki_aydan_kalan=1)
#         db.session.add(siparis)
#         db.session.commit()
#         user = User.query.filter(User.id == 18).first()
#         user.toplam_siparis_tutari += saha_sheet["H" + str(index)].value
#         db.session.add(user)
#         db.session.commit()
#         print("burda")
#     elif temsilci == 'Abdülmecit Şen':
#         siparis = Siparis(proje_no=saha_sheet["B" + str(index)].value, musteri_adi=saha_sheet["A" + str(index)].value,
#                           siparis_tutari=saha_sheet["H" + str(index)].value, user_id=49,
#                           siparis_son_durum=saha_sheet["C" + str(index)].value,
#                           son_odeme_tarihi=saha_sheet["E" + str(index)].value,
#                           isin_alinma_tarihi=saha_sheet["G" + str(index)].value,
#                           evrak_cikis_tarihi=saha_sheet["D" + str(index)].value, onceki_aydan_kalan=1)
#         db.session.add(siparis)
#         db.session.commit()
#         user = User.query.filter(User.id == 49).first()
#         user.toplam_siparis_tutari += saha_sheet["H" + str(index)].value
#         db.session.add(user)
#         db.session.commit()
#         print("burda")
#     elif temsilci == 'Kadir İnanç Tekin':
#         siparis = Siparis(proje_no=saha_sheet["B" + str(index)].value, musteri_adi=saha_sheet["A" + str(index)].value,
#                           siparis_tutari=saha_sheet["H" + str(index)].value, user_id=49,
#                           siparis_son_durum=saha_sheet["C" + str(index)].value,
#                           son_odeme_tarihi=saha_sheet["E" + str(index)].value,
#                           isin_alinma_tarihi=saha_sheet["G" + str(index)].value,
#                           evrak_cikis_tarihi=saha_sheet["D" + str(index)].value, onceki_aydan_kalan=1)
#         db.session.add(siparis)
#         db.session.commit()
#         user = User.query.filter(User.id == 49).first()
#         user.toplam_siparis_tutari += saha_sheet["H" + str(index)].value
#         db.session.add(user)
#         db.session.commit()
#         print("burda")
#     elif temsilci == 'Esra Demirkol':
#         siparis = Siparis(proje_no=saha_sheet["B" + str(index)].value, musteri_adi=saha_sheet["A" + str(index)].value,
#                           siparis_tutari=saha_sheet["H" + str(index)].value, user_id=46,
#                           siparis_son_durum=saha_sheet["C" + str(index)].value,
#                           son_odeme_tarihi=saha_sheet["E" + str(index)].value,
#                           isin_alinma_tarihi=saha_sheet["G" + str(index)].value,
#                           evrak_cikis_tarihi=saha_sheet["D" + str(index)].value, onceki_aydan_kalan=1)
#         db.session.add(siparis)
#         db.session.commit()
#         user = User.query.filter(User.id == 46).first()
#         user.toplam_siparis_tutari += saha_sheet["H" + str(index)].value
#         db.session.add(user)
#         db.session.commit()
#         print("burda")
#     elif temsilci == 'Emre Can Keklicek':
#         siparis = Siparis(proje_no=saha_sheet["B" + str(index)].value, musteri_adi=saha_sheet["A" + str(index)].value,
#                           siparis_tutari=saha_sheet["H" + str(index)].value, user_id=46,
#                           siparis_son_durum=saha_sheet["C" + str(index)].value,
#                           son_odeme_tarihi=saha_sheet["E" + str(index)].value,
#                           isin_alinma_tarihi=saha_sheet["G" + str(index)].value,
#                           evrak_cikis_tarihi=saha_sheet["D" + str(index)].value, onceki_aydan_kalan=1)
#         db.session.add(siparis)
#         db.session.commit()
#         user = User.query.filter(User.id == 46).first()
#         user.toplam_siparis_tutari += saha_sheet["H" + str(index)].value
#         db.session.add(user)
#         db.session.commit()
#         print("burda")
#     elif temsilci == 'Hulusi Karan':
#         siparis = Siparis(proje_no=saha_sheet["B" + str(index)].value, musteri_adi=saha_sheet["A" + str(index)].value,
#                           siparis_tutari=saha_sheet["H" + str(index)].value, user_id=48,
#                           siparis_son_durum=saha_sheet["C" + str(index)].value,
#                           son_odeme_tarihi=saha_sheet["E" + str(index)].value,
#                           isin_alinma_tarihi=saha_sheet["G" + str(index)].value,
#                           evrak_cikis_tarihi=saha_sheet["D" + str(index)].value, onceki_aydan_kalan=1)
#         db.session.add(siparis)
#         db.session.commit()
#         user = User.query.filter(User.id == 48).first()
#         user.toplam_siparis_tutari += saha_sheet["H" + str(index)].value
#         db.session.add(user)
#         db.session.commit()
#         print("burda")
#     elif temsilci == "Doğukan Karabulut":
#         siparis = Siparis(proje_no=saha_sheet["B" + str(index)].value, musteri_adi=saha_sheet["A" + str(index)].value,
#                           siparis_tutari=saha_sheet["H" + str(index)].value, user_id=48,
#                           siparis_son_durum=saha_sheet["C" + str(index)].value,
#                           son_odeme_tarihi=saha_sheet["E" + str(index)].value,
#                           isin_alinma_tarihi=saha_sheet["G" + str(index)].value,
#                           evrak_cikis_tarihi=saha_sheet["D" + str(index)].value, onceki_aydan_kalan=1)
#         db.session.add(siparis)
#         db.session.commit()
#         user = User.query.filter(User.id == 48).first()
#         user.toplam_siparis_tutari += saha_sheet["H" + str(index)].value
#         db.session.add(user)
#         db.session.commit()
#         print("burda")
#     elif temsilci == "Emin Güçoğlu":
#         siparis = Siparis(proje_no=saha_sheet["B" + str(index)].value, musteri_adi=saha_sheet["A" + str(index)].value,
#                           siparis_tutari=saha_sheet["H" + str(index)].value, user_id=48,
#                           siparis_son_durum=saha_sheet["C" + str(index)].value,
#                           son_odeme_tarihi=saha_sheet["E" + str(index)].value,
#                           isin_alinma_tarihi=saha_sheet["G" + str(index)].value,
#                           evrak_cikis_tarihi=saha_sheet["D" + str(index)].value, onceki_aydan_kalan=1)
#         db.session.add(siparis)
#         db.session.commit()
#         user = User.query.filter(User.id == 48).first()
#         user.toplam_siparis_tutari += saha_sheet["H" + str(index)].value
#         db.session.add(user)
#         db.session.commit()
#         print("burda")
#
#     elif temsilci == "Batuhan Yıldırım":
#         siparis = Siparis(proje_no=saha_sheet["B" + str(index)].value, musteri_adi=saha_sheet["A" + str(index)].value,
#                           siparis_tutari=saha_sheet["H" + str(index)].value, user_id=48,
#                           siparis_son_durum=saha_sheet["C" + str(index)].value,
#                           son_odeme_tarihi=saha_sheet["E" + str(index)].value,
#                           isin_alinma_tarihi=saha_sheet["G" + str(index)].value,
#                           evrak_cikis_tarihi=saha_sheet["D" + str(index)].value, onceki_aydan_kalan=1)
#         db.session.add(siparis)
#         db.session.commit()
#         user = User.query.filter(User.id == 48).first()
#         user.toplam_siparis_tutari += saha_sheet["H" + str(index)].value
#         db.session.add(user)
#         db.session.commit()
#         print("burda")
#     index += 1

# işten ayrılanları tuğba kılıç'a aktarma kodu
#
# excel = load_workbook("tuğba kılıç'a aktarılacaklar.xlsx")
# sheet = excel.active
# index = 2
# while index<=sheet.max_row:
#     siparis = Siparis(proje_no=sheet["B" + str(index)].value, musteri_adi=sheet["A" + str(index)].value,
#                               siparis_tutari=sheet["H" + str(index)].value, user_id=21,
#                               siparis_son_durum=sheet["C" + str(index)].value,
#                               son_odeme_tarihi=sheet["E" + str(index)].value,
#                               isin_alinma_tarihi=sheet["G" + str(index)].value,
#                               evrak_cikis_tarihi=sheet["D" + str(index)].value)
#     db.session.add(siparis)
#     db.session.commit()
#     index += 1
#





#
# temsilci = load_workbook("derya-davutoğlu.xlsx")
# temsilci_sheet = temsilci.active
# index = 2
# guncel = Siparis.query.filter(extract('month', Siparis.son_odeme_tarihi ) == 4).all()
# for gun in guncel:
#     temsilci_sheet["A" + str(index)].value = gun.musteri_adi
#     temsilci_sheet["B" + str(index)].value = gun.siparis_tutari
#     temsilci_sheet["C" + str(index)].value = gun.tahsilat
#     temsilci_sheet["D" + str(index)].value = gun.proje_no
#     temsilci_sheet["E" + str(index)].value = gun.user_id
#
#     index += 1
# temsilci.save("derya-davutoğlu.xlsx")

# siparisler = Siparis.query.filter(extract('month', Siparis.son_odeme_tarihi) == 4).all()
# index = 1
# for siparis in siparisler:
#     index += 1
# print(index)


# siparisler = Siparis.query.filter(extract('month', Siparis.son_odeme_tarihi) == 5).all()
# toplam = 0
# for siparis in siparisler:
#     user = User.query.get(siparis.user_id)
#     if user.id == 4:
#         print(siparis.siparis_tutari)
#         toplam += siparis.siparis_tutari
# print(toplam)


## Günlük CRM Aktarımı için Excel oluşturan script
from openpyxl import Workbook
from datetime import datetime
import requests

excel = Workbook()
sheet = excel.active

paramss = {"d": "2020-08-07"}
tasklogs = requests.get('https://api.sehatekgis.com/tasklogss', params=paramss).json()['tasklogs']

field_dict = {
    "A": "Kurum Adı", "B": "Tür", "C": "Eposta 1", "D": "Eposta 2", "E": "Eposta 3", "F": "Telefon 1",
    "G": "Telefon 1 Tür", "H": "Telefon 2", "I": "Telefon 2 Tür", "J": "Telefon 3", "K": "Telefon 3 Tür", "L": "Adres",
    "M": "İl", "N": "İlçe", "O": "Ülke", "P": "Posta Kodu", "Q": "Konum", "R": "Notlar", "S": "İrtibat Kişisi",
    "T": "Bina Saha Durumu", "U": "Saha Blok Sayısı", "V": "Saha Daire Sayısı", "W": "Güvenlik Kamerası",
    "X": "Görüntülü Konuşma", "Y": "Saha Yapı Tipi", "Z": "Broşür Fotoğrafı Linki", "AA": "Dış Cephede Mantolama",
    "AB": "PVC", "AC": "EKB Dönemi", "AD": "EKB Alma Tarihi", "AE": "Ziyareti Gerçekleştiren", "AF": "Giriş Kapısı",
    "AG": "Ziyaret Tarihi","AH": "Site - Bina Adı"
}

heading_row = []

for key, value in field_dict.items():
    heading_row.append(value)

sheet.append([])
sheet.append([])
sheet.append([])
sheet.append([])
sheet.append(heading_row)

for tasklog in tasklogs:
    newObject = tasklog['newObject']

    if newObject['visCamera'] == True:
        visCamera = 'VAR'
    else:
        visCamera = 'YOK'

    if newObject['visTalk'] == True:
        visTalk = 'VAR'
    else:
        visTalk = 'YOK'

    if newObject['visTalk'] == True:
        visTalk = 'VAR'
    else:
        visTalk = 'YOK'

    if newObject['brochurePhoto'] is not None:
        brochurePhoto = 'https://kolayekb.com/' + newObject['brochurePhoto']
    else:
        brochurePhoto = ''

    if newObject['exteriorInsulation'] == True:
        extIns = 'VAR'
    else:
        extIns = 'YOK'

    if newObject['pvc'] == True:
        pvc = 'VAR'
    else:
        pvc = 'YOK'

    if newObject['gateStatus'] == True:
        gateStatus = 'YENİ'
    else:
        gateStatus = 'ESKİ'

    if newObject['ekbDateGt'] == True:
        ekbDateGt = '2017 Kasım Öncesi'
    elif newObject['ekbDateGt'] == False:
        ekbDateGt = '2017 Kasım Sonrası'
    else:
        ekbDateGt = ''

    site_name = newObject['siteName']

    adres = newObject['neighbor']['name'] + ", " + newObject['street'] + ", No: " + str(newObject['buildingNumber'])
    county = newObject['neighbor']['county']['name']
    city = newObject['neighbor']['county']['city']['name']
    if newObject['ekbGetDate'] is not None:
        ekbGetDate = datetime.strptime(newObject['ekbGetDate'], '%Y-%m-%d').strftime('%d/%m/%Y')
    else:
        ekbGetDate = None

    data_dict = {
        "A": newObject['name'], "B": "Saha - Bina", "C": newObject['contactMail'], "D": "", "E": "", "F": newObject['contactPhone'],
        "G": "", "H": "", "I": "", "J": "", "K": "", "L": adres, "M": city, "N": county, "O": "", "P": "", "Q": "",
        "R": newObject['notes'], "S": newObject['contactName'], "T": newObject['status'], "U": newObject['blockAmount'],
        "V": newObject['flatAmount'], "W": visCamera, "X": visTalk, "Y": newObject['buildingType'].capitalize(),
        "Z": brochurePhoto, "AA": extIns, "AB": pvc, "AC": ekbDateGt,
        "AD": ekbGetDate, "AE": tasklog['userName'],
        "AF": gateStatus, "AG": datetime.strptime(tasklog['date'], '%Y-%m-%d').strftime('%d/%m/%Y'),
        "AH": site_name
    }

    data_list = []


    for key, value in data_dict.items():
        data_list.append(value)

    sheet.append(data_list)


excel.save('aktarım 07 august 2020.xlsx')
#
# import pandas as pd
# excel = pd.read_excel('aktarım 9 temmuz 2020.xlsx')
# excel = excel.drop_duplicates(subset ='Kurum Adı',keep = 'last', inplace = True)
# #
# #
# #
# excel.to_excel('aktarım 9 temmuz duplicated 2020.xlsx')

# paraşütteki ödemeleri portaldan düşme kodu
# #
# #
# toplu_index = 2
# parasut_excel = load_workbook('0ka.xlsx')
# parasut_sheet = parasut_excel.active
# siparis_excel = load_workbook('mart ayı tahsilat portalı-satış.xlsx')
# siparis_sheet = siparis_excel.active
# parasut_index = 3106
# siparisler = Siparis.query.filter((Siparis.son_odeme_tarihi > '2020-03-01')).all()
# print(type(siparisler))
# while parasut_index <= parasut_sheet.max_row:
#     siparis_no_parasut = parasut_sheet["D" + str(parasut_index)].value.split('/')[0]
#     siparis_tutari_parasut = parasut_sheet['E' + str(parasut_index)].value
#     create_date = parasut_sheet['B' + str(parasut_index)].value
#     for siparis in siparisler:
#         if siparis_no_parasut == siparis.proje_no and siparis.siparis_tutari == siparis_tutari_parasut and siparis.tahsilat == 0:
#             print("TAM ÖDEME YAPILMIŞTIR.")
#             print(parasut_index)
#             print(siparis_no_parasut)
#             print(siparis.proje_no)
#             print(siparis_tutari_parasut)
#             print(siparis.siparis_tutari)
#             user = User.query.get(siparis.user_id)
#             user.toplam_siparis_tahsilati += siparis.siparis_tutari
#             print("userin toplam tahsilati eklendi")
#             guncel_odeme = GuncelOdeme(tutar=siparis.siparis_tutari, create_date=create_date, siparis_id=siparis.id)
#             siparis.tahsilat += siparis.siparis_tutari
#             print("guncel ödeme tablosuna ilgili ödeme eklendi")
#             print("siparisin tahsilati siparis tutari kadar artti")
#             db.session.add(guncel_odeme)
#             db.session.commit()
#             break
#         elif siparis_no_parasut == siparis.proje_no and float(siparis.siparis_tutari) > float(siparis_tutari_parasut) and siparis.tahsilat == 0:
#             print('AZ ÖDEME YAPILMIŞ')
#             print(parasut_index)
#             print(siparis_no_parasut)
#             print(siparis.proje_no)
#             print(siparis_tutari_parasut)
#             print(siparis.siparis_tutari)
#             user = User.query.get(siparis.user_id)
#             user.toplam_siparis_tahsilati += float(siparis_tutari_parasut)
#             print("userin toplam tahsilati eklendi")
#             guncel_odeme = GuncelOdeme(tutar=siparis_tutari_parasut, create_date=create_date, siparis_id=siparis.id)
#             siparis.tahsilat += float(siparis_tutari_parasut)
#             print("guncel ödeme tablosuna ilgili ödeme eklendi")
#             print("siparisin tahsilati parasut tahsilat tutari kadar artti")
#             db.session.add(guncel_odeme)
#             db.session.commit()
#             break
#         elif siparis_no_parasut == siparis.proje_no and siparis.siparis_tutari < siparis_tutari_parasut and siparis.tahsilat == 0:
#             print('TOPLU ÖDEME YAPILMIŞ')
#             print(parasut_index)
#             print(siparis_no_parasut)
#             print(siparis.proje_no)
#             print(siparis_tutari_parasut)
#             print(siparis.siparis_tutari)
#             user = User.query.get(siparis.user_id)
#             user.toplam_siparis_tahsilati += siparis.siparis_tutari
#             print("userin toplam tahsilati eklendi")
#             guncel_odeme = GuncelOdeme(tutar=siparis.siparis_tutari, create_date=create_date, siparis_id=siparis.id)
#             siparis.tahsilat += siparis.siparis_tutari
#             print("guncel ödeme tablosuna ilgili ödeme eklendi")
#             print("siparisin tahsilati siparis tutari kadar artti")
#             db.session.add(guncel_odeme)
#             db.session.commit()
#             toplu_odeme_excel = load_workbook('şubdat toplu ödeme.xlsx')
#             toplu_odeme_sheet = toplu_odeme_excel.active
#             toplu_odeme_sheet['A' + str(toplu_index)].value = siparis.proje_no
#             toplu_odeme_sheet['B' + str(toplu_index)].value = siparis.siparis_tutari
#             toplu_odeme_sheet['C' + str(toplu_index)].value = siparis_tutari_parasut
#             toplu_index +=1
#             toplu_odeme_excel.save("şubadt ayı toplu ödemeler.xlsx")
#
#             break
#
#     print(parasut_index)
#     parasut_index += 1
#     print('*********')
#
# toplu_odeme_excel.save("şubadt ayı toplu ödemeler.xlsx")


#
# while parasut_index <= parasut_sheet.max_row:
#     siparis_no = parasut_sheet["D" + str(parasut_index)].value.split('/')[0]
#     siparis = Siparis.query.filter_by(proje_no=siparis_no).first()
#
#     print(parasut_index)
#     print(siparis_no)
#     print(siparis_sheet['B' + str(siparis_index)].value)
#     print(siparis.siparis_tutari)
#     print(parasut_sheet['E' + str(parasut_index)].value)
#     while siparis_index <= siparis_sheet.max_row:
#         if (siparis_no[0] == '0' or siparis_no[0] == '1' or siparis_no[0] == '2') and siparis_no == siparis_sheet['B' + str(siparis_index)].value:
#             if(siparis.tahsilat == 0 and siparis_sheet['H' + str(siparis_index)].value != parasut_sheet['E' + str(parasut_index)].value):
#                 if(siparis_sheet['H' + str(siparis_index)].value > parasut_sheet['E' + str(parasut_index)].value):
#                     user = User.query.get(siparis.user_id)
#                     print("AZ ODEME YAPILMIS")
#                     print("Sipariş Tutarı:  +   " + siparis.siparis_tutari)
#                     print("Tahsilat Tutarı:     +   " + parasut_sheet['E' + str(parasut_index)].value)
#                     parasut_sheet['G' + str(parasut_index)].value = 'AZ ÖDEME'
#
#                     print(siparis.proje_no + "  +   " + siparis.siparis_tutari)
#                     user.toplam_siparis_tahsilati += parasut_sheet['E' + str(parasut_index)].value
#                     print("userin toplam tahislati eklendi")
#                     guncel_odeme = GuncelOdeme(tutar=parasut_sheet['E' + str(parasut_index)].value,
#                                                create_date=parasut_sheet['B' + str(parasut_index)].value, siparis_id=siparis.id)
#                     siparis.tahsilat += parasut_sheet['E' + str(parasut_index)].value
#                     print("guncel odeme tablosuna ilgili odeme eklendi")
#                     print("*************************************")
#                     print(siparis.proje_no)
#                     db.session.add(guncel_odeme)
#                     db.session.commit()
#                     print("siparisin tahsilat sutunu parasut odemesi kadar artti")
#
#                     break
#                 if (siparis_sheet['H' + str(siparis_index)].value < parasut_sheet['E' + str(parasut_index)].value):
#                     print('TOPLU ÖDEME YAPMIŞ OLABİLİR')
#                     parasut_sheet['G' + str(parasut_index)].value = 'TOPLU ODEME YAPMIS OLABİLİR'
#                     user = User.query.get(siparis.user_id)
#                     print(siparis.proje_no)
#                     user.toplam_siparis_tahsilati += siparis.siparis_tutari
#                     print("userin toplam tahislati eklendi")
#                     guncel_odeme = GuncelOdeme(tutar=siparis.siparis_tutari,
#                                                create_date=parasut_sheet['B' + str(parasut_index)].value, siparis_id=siparis.id)
#                     siparis.tahsilat += siparis.siparis_tutari
#                     print("guncel odeme tablosuna ilgili odeme eklendi")
#                     print("*************************************")
#                     print(siparis.proje_no)
#                     db.session.add(guncel_odeme)
#                     db.session.commit()
#                     print("siparisin tahsilat sutunu odeme kadar artti")
#                     break
#                 if (siparis_sheet['H' + str(siparis_index)].value == parasut_sheet['E' + str(parasut_index)].value):
#                     print('TAM ÖDEME YAPILMIŞ')
#                     parasut_sheet['G' + str(parasut_index)].value = 'TAM ÖDEME'
#                     user = User.query.get(siparis.user_id)
#                     print(siparis.proje_no)
#                     user.toplam_siparis_tahsilati += siparis.siparis_tutari
#                     print("userin toplam tahislati eklendi")
#                     guncel_odeme = GuncelOdeme(tutar=siparis.siparis_tutari,
#                                                create_date=parasut_sheet['B' + str(parasut_index)].value, siparis_id=siparis.id)
#                     siparis.tahsilat += siparis.siparis_tutari
#                     print("guncel odeme tablosuna ilgili odeme eklendi")
#                     print("*************************************")
#                     print(siparis.proje_no)
#                     db.session.add(guncel_odeme)
#                     db.session.commit()
#                     print("siparisin tahsilat sutunu odeme kadar artti")
#                     break
#
#         # elif (siparis_no[0] == '0' or siparis_no[0] == '1' or siparis_no[0] == '2') and siparis_no == siparis_sheet['B' + str(siparis_index)].value and siparis_sheet['H' + str(siparis_index)].value != parasut_sheet['F' + str(parasut_index)].value:
#         #     siparis = Siparis.query.filter_by(proje_no=siparis_no).first()
#         #
#         #     if siparis.tahsilat != parasut_sheet['F' + str(parasut_index)].value:
#         #         print('TOPLU ODEME YAPMIS OLABILIR!')
#         #
#         #         print(siparis.proje_no)
#         #
#         #         user = User.query.get(siparis.user_id)
#         #         print(siparis.proje_no)
#         #         user.toplam_siparis_tahsilati += siparis_sheet['H' + str(siparis_index)].value
#         #         print("userin toplam tahislati eklendi")
#         #         guncel_odeme = GuncelOdeme(tutar=siparis_sheet['H' + str(siparis_index)],
#         #                                create_date=parasut_sheet['B' + str(parasut_index)].value, siparis_id=siparis.id)
#         #         siparis.tahsilat += siparis_sheet['H' + str(siparis_index)].value
#         #         print("guncel odeme tablosuna ilgili odeme eklendi")
#         #         print(siparis.proje_no)
#         #         db.session.add(guncel_odeme)
#         #         db.session.commit()
#         #         print('**********************************************')
#         #
#         #     break
#         siparis_index += 1
#     parasut_index += 1
#     siparis_index = 2
#
# parasut_excel.save('şubddat ayı tahsilatları paraşüt revizee.xlsx')

# from sqlalchemy import and_
# # # birinin tahsilat portalını başkası ile birleştirme ( aylık olarak )
# siparisler = Siparis.query.filter(and_(Siparis.user_id == 9, extract('month', Siparis.son_odeme_tarihi) == 12)).all()
# for siparis in siparisler:
#     siparis.user_id = 17
#     user = User.query.get(17)
#     user.toplam_siparis_tahsilati += siparis.tahsilat
#     user.toplam_siparis_tutari += siparis.siparis_tutari
#     user2 = User.query.get(9)
#     user2.toplam_siparis_tahsilati -= siparis.tahsilat
#     user2.toplam_siparis_tutari += siparis.siparis_tutari
#     db.session.commit()
#
# tahsil_edilemeyen_excel = Workbook()
# sheet = tahsil_edilemeyen_excel.active
# siparisler = Siparis.query.filter(extract('month', Siparis.son_odeme_tarihi = 10)).all()
# index = 2
# for siparis in siparisler:
#     for odeme in siparis.odeme:
#         user= User.query.get(siparis.user_id)
#         sheet["A" +str(index)].value = user.name
#         sheet["B" + str(index)].value = siparis.musteri_adi
#         sheet["C" + str(index)].value = siparis.proje_no
#         sheet["D" + str(index)].value = siparis.siparis_tutari
#         sheet["E" + str(index)].value = siparis.tahsilat
#         print(index)
#         index += 1
#
# tahsil_edilemeyen_excel.save('Ekim Ayı Portalı Tahsil Edilemeyen İşler.xlsx')


